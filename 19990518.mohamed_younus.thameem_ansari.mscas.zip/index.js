const form = document.querySelector('[data-form]');
const text_area_en = document.querySelector('[data-text_area_en]');
const text_area_fr = document.querySelector('[data-text_area_fr]');
const file = document.querySelector('[data-file]');
const download = document.querySelector('[data-download]');

let data = {};

const capitalize = s => (s && s[0].toUpperCase() + s.slice(1)) || ""

const downloadTxtFile = (text) => {
    const element = document.createElement("a");
    const files = new Blob([text], {
        type: "text/plain",
    });
    element.href = URL.createObjectURL(files);
    element.download = "t8.shakespeare.txt";
    document.body.appendChild(element);
    element.click();
};

(async function () {
    let fr = new FileReader();
    fr.onload = function () {
        let list = fr.result.split('\n');
        list.forEach(function (line) {
            let [key, value] = line.split(',');
            data[key] = value;
            // console.log({ key, value });
        })
        data['']="";
    }
    let res = await fetch('french_dictionary.csv')
    let blob = await res.blob();
    fr.readAsText(blob);
}())

download.addEventListener("click",()=>{
    let text = text_area_fr.value
    downloadTxtFile(text)
})

form.addEventListener('submit', (e) => {
    e.preventDefault();
    var fr = new FileReader();
    fr.onload = function () {
        let res = fr.result
        text_area_en.value = fr.result;
        for (const [key, value] of Object.entries(data)) {
            res = res.replace(key, value);
            res = res.replace(key.toUpperCase(), value);
            res = res.replace(key.toLocaleLowerCase(), value);
            res = res.replace(capitalize(key), value);
        }
        text_area_fr.value = res;
        download.classList.remove('d-none');

    }
    fr.readAsText(file.files[0]);
})